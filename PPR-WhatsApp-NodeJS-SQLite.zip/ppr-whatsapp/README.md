# PPR Tax Consultancy — WhatsApp office automation

Node.js 24 + SQLite, built to connect to the existing NestJS OpenWA gateway on port 2785. No npm dependencies, paid AI API, Redis or additional database server. OpenWA is a separate existing service; this ZIP does not install it or contain its session credentials.

## What a client experiences

1. Sends **hi** → professional welcome, office-assistant disclosure and eight service areas.
2. Replies **2** → GST services; replies **1** → GST Registration details.
3. Replies **BOOK** → consent to storing a callback enquiry.
4. Replies **YES**, their name and a brief enquiry → request saved; automation pauses for staff.
5. Staff see the request at the office desk, contact the customer from the existing OpenWA dashboard/WhatsApp, then mark it contacted or closed.

CONTACT shows the verified website contact details. HUMAN records a handoff in the contact list and pauses automation. STOP stops it; START resumes it. MENU/CANCEL returns to service navigation unless the chat is paused or stopped. Service names and `SERVICE <id>` also work directly.

The bot does not book a guaranteed appointment, file tax returns, collect payments, promise refunds, or determine eligibility. Staff agree scope, documents, fees and timing with the client.

## Website details

Extracted on 4 October 2026 from https://ppr-tax-consultancy-eilu.bolt.host and its public JavaScript bundle. See `docs/EXTRACTED-BUSINESS.md` and `config/business.json`.

- PPR Tax Consultancy; K. Umamaheswara Reddy, **Founder & Lead Consultant**.
- +91 9618561434; pprtaxconsultancy@gmail.com.
- Miyapur, Hyderabad, Telangana 500049; full address in the configuration.
- Monday–Friday 9:30 AM–7:00 PM; Saturday 10:00 AM–5:00 PM; Sunday closed, India time.
- Eight categories, 36 entries (34 unique service names; the website repeats Tax Planning and Certification Services).

The website's qualification is reproduced as “B.Com (CA)”; this package does not independently certify professional credentials. No fees or service turnaround times were found.

## Clickable service selection

This OpenWA implementation uses reliable plain-text replies, rather than promising unsupported native WhatsApp buttons/lists. `/catalog` is a responsive service page with clickable WhatsApp enquiry links. A click opens WhatsApp with `SERVICE <id>` prefilled; the customer still presses Send. This is a separate service catalogue page, not the native WhatsApp Business product catalogue.

To include catalogue links in the bot replies, configure an actual HTTPS `PUBLIC_BASE_URL` served by your reverse proxy. Leave it blank until the URL exists. Native in-chat interactive business buttons require a compatible API; they are not implemented in this package. The business number in `config/business.json` must be the number linked to your OpenWA session for catalogue links to reach the bot.

## First try it safely

With Node.js **24.x** installed:

```bash
cd ppr-whatsapp
npm test
npm run demo
```

Open http://127.0.0.1:3090 on the same machine. Sign in with the demo token from `.env.demo` (demo use only): `demo-admin-token-for-local-testing-only`.

In a second terminal:

```bash
node --env-file=.env.demo scripts/demo-conversation.js
```

This exercises the signed webhook, database and background worker without sending WhatsApp messages. A repeat demo may find the fixture contact paused after its previous handoff: use Resume at the office desk before replaying it.

For an EC2 server, keep the demo private and use an SSH tunnel from your computer:

```bash
ssh -L 3090:127.0.0.1:3090 ubuntu@YOUR_EC2_PUBLIC_IP
```

Keep the tunnel open; use http://127.0.0.1:3090 on your computer. Do not open AWS port 3090 publicly for this test.

## Connect to your existing OpenWA — Docker on Ubuntu

1. Extract the ZIP beside, not inside, the OpenWA source directory. Confirm your OpenWA session is connected and note its **session UUID**, not its display name.
2. Create the configuration using Node 24 (`node scripts/create-env.js`), or use Docker if Node is not installed on Ubuntu. Compose needs `.env` before startup, so build directly first:

```bash
sudo docker build -t ppr-whatsapp .
sudo docker run --rm --user "$(id -u):$(id -g)" -v "$PWD:/work" -w /work ppr-whatsapp node scripts/create-env.js
```

Alternatively, with Node 24 installed: `node scripts/create-env.js`.

3. Edit `.env` with `nano .env`: set your real `OPENWA_API_KEY` and `OPENWA_SESSION_ID`. Keep the generated ADMIN_TOKEN and WEBHOOK_SECRET different and private. Do not send keys in chat.
4. Confirm `openwa-api` is on the external Docker network `openwa-network`. If your network or container service name differs, update `compose.yaml` using `sudo docker network ls` and your OpenWA compose file. No extra OpenWA container is created here.
5. The gateway may block private webhook targets. In your **existing OpenWA** configuration, keep `WEBHOOK_SSRF_PROTECT=true` and append ONLY `ppr-bot` to `SSRF_ALLOWED_HOSTS` (preserve any existing hosts). Ensure the existing OpenWA compose service actually forwards this environment variable, for example under its `environment`: `SSRF_ALLOWED_HOSTS: ${SSRF_ALLOWED_HOSTS}`. Restart that service to apply its configuration. Do not disable SSRF protection globally. This is a documented trusted-sidecar allowlist; check it against your installed gateway version.
6. Start the bot and register its signed webhook:

```bash
sudo docker compose up -d
sudo docker compose exec ppr-bot node scripts/register-webhook.js
sudo docker compose logs --tail=30 ppr-bot
```

`compose.yaml` supplies the private URLs `http://openwa-api:2785` and `http://ppr-bot:3090/webhook/openwa`. These override the host-based example URLs. Webhook registration deliberately does not create duplicates; if already registered, verify its secret and event selection in OpenWA manually. Subscribe only to `message.received`.

7. Open the office desk through the SSH tunnel and use **ADMIN_TOKEN** from your `.env`. Send hi to the linked business WhatsApp number from a second number. Walk through the service flow and confirm both the WhatsApp replies and the saved callback request. Disable overlapping OpenWA auto-reply rules for this session to prevent competing replies.

Do not put a new live system in front of clients until this real-number check passes. The package was tested with fixtures and mocked sends; it was not connected to your EC2 or WhatsApp account here.

## If running directly with Node

```bash
node scripts/create-env.js
# Edit .env with your own gateway key and session UUID.
npm start
```

Use OPENWA_BASE_URL=http://127.0.0.1:2785 only when the gateway is reachable there from this Node process. WEBHOOK_URL must be reachable **from the gateway**, which has a different localhost when in Docker. Choose a reachable private address or a real HTTPS URL; do not assume Docker's localhost is the Ubuntu host. Register with `npm run register:webhook` after configuring gateway allowlisting as needed.

## CEO welcome

Default wording matches the website's Founder & Lead Consultant title. The request asked for a CEO welcome; set `CEO_MODE=true` only if K. Umamaheswara Reddy is the correct CEO to name. It sends:

> A welcome from K. Umamaheswara Reddy, CEO: “Welcome to PPR Tax Consultancy. Thank you for trusting us with your tax and business compliance needs. Our team is here to assist you.”

It then clearly says the sender is the automated office assistant. To use a different CEO/name or custom wording, edit `leader` and `ceoWelcome` in `config/business.json` and leave CEO_MODE=false so the custom message is used. Restart after configuration changes.

## Office desk and operations

- The dashboard token is held in browser memory, not localStorage or cookies.
- View latest 200 contacts/leads and 100 outgoing messages; larger history remains in SQLite.
- Pause/resume contacts; mark callback requests contacted/closed; discard failed replies.
- A timeout, server error or restart during sending marks a reply **review**. Check WhatsApp before manually retrying. Later messages to that chat wait behind review items. Discard a delivered reply to release the queue.
- HTTP 429 rejections retry at most five send attempts. Other client errors are failed. No automatic retry for uncertain acceptance.
- One bot instance per SQLite database. Local persistent volume, not NFS. Do not run multiple workers against it.
- Messages are processed FIFO by received order; outbox sends are serialized at approximately one per 750 ms. This is a modest single-office design, not a bulk broadcast system.
- Staff monitor handoffs and leads in the office desk; there are no external staff notifications in this version.
- Welcome and intake remain available after office hours; hours are displayed and callbacks remain pending. No promise of immediate response.

Backup with `npm run backup`, or in Docker:

```bash
sudo docker compose exec ppr-bot node scripts/backup.js
# Copy the backup directory out of the container immediately; it is not a volume.
sudo docker compose cp ppr-bot:/app/backups ./backups
```

The helper uses SQLite's online backup API for a consistent backup even under WAL. Encrypt backups and keep them outside the server. To restore: stop the bot, preserve the existing data, place the backup at the configured database path with ownership writable by the node user, and start it. Do not combine an old backup with the previous database's WAL/SHM files. Restoring can reintroduce old queue rows; inspect outgoing replies before going live.

## Data and access

Signed webhooks use HMAC-SHA256 over exact raw bytes, constant-time comparison, session filtering, stable message-ID deduplication and a 24-hour delivery timestamp window. Group, media and outgoing messages are ignored. The receiver rejects bodies above 64 KiB. Configure OpenWA to omit inline media if unnecessary, so large events do not exceed that bound.

Processed inbox text is cleared. Contacts, enquiries and outgoing text are plaintext in SQLite, protected by permissions; use encrypted EC2/EBS storage. RETENTION_DAYS defaults to 30: completed inbox entries, sent/cancelled/simulated outgoing replies, closed leads and inactive unpaused contacts are purged daily. Open leads, unresolved replies and stopped/human contacts remain for staff action. STOP is not a deletion request; deletion requests must be handled by the office. OpenWA maintains its own data separately.

For public access, use an HTTPS reverse proxy with request limits. Keep staff access behind a VPN/IP restriction as well as the token. Do not transmit admin tokens/API keys over public HTTP. Expose only `/catalog`, `/style.css` and, if required, `/webhook/openwa` publicly; the dashboard and `/api/admin/` can stay private. Do not expose `.env` or SQLite files. The included Docker port mapping is loopback-only.

## Cost and compatibility

The automation code uses no paid SaaS or per-message AI service. AWS, domain and hosting charges still apply. Your current OpenWA engine determines most WhatsApp session resource usage. Node 24's built-in SQLite API is used and may emit an experimental notice depending on the runtime release.

Integration targets the **rmyndharis/OpenWA-style NestJS API** at port 2785, not the unrelated `@open-wa/wa-automate` Easy API. Check your installed `/api/docs` or source for the webhook and send-text schema before activating. Unofficial WhatsApp Web automation can disconnect or encounter account restrictions; no stability or zero-ban guarantee is possible.

## Included files

`src/` backend and queue; `config/business.json` editable business/services; `public/` office desk and styling; `/catalog` generated from the config; `scripts/` environment setup, webhook registration, demo and backup; `test/` 12 automated checks; Dockerfile and compose; `BUILD-PROMPT.md` reusable development specification; `docs/` extracted website facts, source links and verification results.
