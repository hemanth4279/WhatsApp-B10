export function mainMenu(b) {
 return `*Welcome to ${b.name}*\n\n${b.ceoWelcome || `Thank you for contacting us. Our practice is led by ${b.leader}, ${b.leaderTitle}.`}\n\nI’m the automated office assistant. I can explain our services and arrange a callback with our team.\n\n*Choose a service area:*\n${b.categories.map(c=>`${c.id}. ${c.name}`).join('\n')}\n\nReply with a number. Type CONTACT for office details or HUMAN to speak with our team.\nWe store your chat ID and enquiry to respond. Type STOP to stop automated replies. Please do not send OTPs, passwords, PAN/Aadhaar numbers or financial documents here.`;
}
const allServices=b=>b.categories.flatMap(c=>c.services);
export function flow(b, current={}, input='', options={}) {
 let state={...current}, text=input.trim(), upper=text.toUpperCase();
 const reply=(message)=>({state,text:message});
 if (upper==='STOP') {state={stage:'stopped'};return reply('Automated replies are now stopped. Type START whenever you wish to resume.');}
 if (upper==='START') {state={stage:'menu'};return reply(mainMenu(b));}
 if (state.stage==='stopped') return {state,text:null};
 if (upper==='HUMAN') {state={stage:'human'};return reply(`Your request to speak with our team is recorded. Automated replies are paused. For urgent enquiries call ${b.phone}.\nOffice hours: ${b.hours}.`);}
 if (state.stage==='human') return {state,text:null};
 if (upper==='CANCEL'||upper==='MENU'||/^(HI|HELLO|HEY|NAMASTE|GOOD MORNING)$/i.test(text)) {state={stage:'menu'};return reply(mainMenu(b));}
 if (upper==='CONTACT') return reply(`*${b.name}*\n${b.phone}\n${b.email}\n${b.address}\n${b.hours}\n${b.website}\n\nType MENU for services or HUMAN for our team.`);
 if (upper==='SERVICES') {state={stage:'menu'};return reply(mainMenu(b));}
 if (state.stage==='consent') {
  if(upper!=='YES')return reply('Reply YES to allow us to store your name and enquiry for a callback, or CANCEL to return to the menu.');
  state.stage='name';return reply('Thank you. What name should our team use? Please send only your name.');
 }
 if (state.stage==='name') {
  if(text.length<2||text.length>80||/\d|https?:/i.test(text))return reply('Please enter a name between 2 and 80 characters, without numbers or links.');
  state.name=text;state.stage='enquiry';return reply('Briefly describe the help you need and your preferred callback time (maximum 500 characters). Do not send identification numbers, passwords or documents. This is a callback request; an appointment is confirmed by our team separately.');
 }
 if (state.stage==='enquiry') {
  if(text.length<3||text.length>500||/\b\d{10,}\b|\b[A-Z]{5}\d{4}[A-Z]\b/i.test(text))return reply('Please send a short enquiry of 3–500 characters without identification numbers. You can type CANCEL.');
  const service=allServices(b).find(s=>s.id===state.service);
  const lead={name:state.name,service:service?.name||'General enquiry',enquiry:text};
  state={stage:'human'};
  return {state,lead,text:`Thank you, ${lead.name}. Your ${lead.service} callback request is recorded for our team. We will review your preferred time and contact you during office hours.\nFees and turnaround time will be agreed after reviewing your requirement.\nFor urgent help: ${b.phone}. Automated replies are paused while our team assists you.`};
 }
 if(upper==='BOOK'||upper==='CALLBACK') {state={stage:'consent',service:state.service};return reply('May we store your name, chat ID and brief enquiry to arrange a callback? Reply YES to agree, or CANCEL. Contact the office to request deletion.');}
 let selected;
 const command=/^SERVICE\s+(\d+)$/i.exec(text);
 if(command)selected=allServices(b).find(s=>s.id===command[1]);
 else if(state.stage==='category' && /^\d+$/.test(text)) {
  selected=b.categories.find(c=>c.id===state.category)?.services[Number(text)-1];
  if(!selected)return reply('Please choose a service number from this category, or type MENU to go back.');
 }
 else if(state.stage==='service' && /^\d+$/.test(text))return reply('Type BOOK for a callback, MENU to choose another service, or HUMAN for our team.');
 if(!selected)selected=allServices(b).find(s=>s.name.toLowerCase()===text.toLowerCase());
 if(selected) {state={stage:'service',service:selected.id};return reply(`*${selected.name}*\n${selected.description}\n\nOur team will review applicability, required documents, fees and timeline before work begins.\nReply BOOK to request a callback, HUMAN to speak with our team or MENU for all services.`);}
 const category=b.categories.find(c=>c.id===text);
 if(category) {state={stage:'category',category:category.id};return reply(`*${category.name}*\n${category.services.map((s,i)=>`${i+1}. ${s.name}`).join('\n')}\n\nReply with a service number.${options.publicBase ? `\nOr view clickable service links: ${options.publicBase}/catalog#category-${category.id}`:''}\nType MENU to go back.`);}
 if(!state.stage){state={stage:'menu'};return reply(mainMenu(b));}
 return reply('Please choose an option from the menu. Type MENU, CONTACT, BOOK, HUMAN or STOP.');
}
