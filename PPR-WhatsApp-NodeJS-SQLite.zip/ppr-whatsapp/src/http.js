import {createServer} from 'node:http';
import {createHmac,timingSafeEqual} from 'node:crypto';
import {readFileSync} from 'node:fs';
import {accept} from './engine.js';
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export function validSignature(raw,signature,secret){
 if(typeof signature!=='string'||!/^sha256=[a-f0-9]{64}$/.test(signature))return false;
 const expected='sha256='+createHmac('sha256',secret).update(raw).digest('hex');
 return timingSafeEqual(Buffer.from(signature),Buffer.from(expected));
}
async function readBody(req){let bytes=0,parts=[];for await(const part of req){bytes+=part.length;if(bytes>65536){const e=Error('Body too large');e.status=413;throw e;}parts.push(part);}return Buffer.concat(parts);}
export function httpServer(db,b,config){
 const server=createServer(async(req,res)=>{
  res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','no-referrer');
  res.setHeader('Cache-Control','no-store');res.setHeader('X-Frame-Options','DENY');
  res.setHeader('Content-Security-Policy',"default-src 'self'; style-src 'self'; script-src 'self'; connect-src 'self'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'");
  const respond=(status,value,type='application/json')=>{res.writeHead(status,{'Content-Type':type+'; charset=utf-8'});res.end(type==='application/json'?JSON.stringify(value):value);};
  try{
   const path=new URL(req.url,'http://localhost').pathname;
   if(req.method==='GET'&&path==='/health')return respond(200,{status:'ok'});
   if(req.method==='POST'&&path==='/webhook/openwa'){
    if(!(req.headers['content-type']||'').startsWith('application/json'))return respond(415,{error:'JSON required'});
    const raw=await readBody(req);
    if(!validSignature(raw,req.headers['x-openwa-signature'],config.secret))return respond(401,{error:'Invalid signature'});
    const event=JSON.parse(raw);const stamp=typeof event.timestamp==='number'?(event.timestamp<1e12?event.timestamp*1000:event.timestamp):Date.parse(event.timestamp);
    if(!Number.isFinite(stamp)||Math.abs(Date.now()-stamp)>86400000)return respond(400,{error:'Delivery timestamp must be within 24 hours'});
    const status=accept(db,event,config.session);
    return respond(status==='invalid'?400:200,{status});
   }
   if(req.method==='GET'&&path==='/catalog'){
    const content=`<!doctype html><html><head><meta name="viewport" content="width=device-width, initial-scale=1"><title>${esc(b.name)} | Services</title><link rel="stylesheet" href="/style.css"></head><body><main><header><span class="eyebrow">PPR · SERVICES</span><h1>${esc(b.name)}</h1><p>Choose a service to open WhatsApp with your selection. Press Send in WhatsApp to begin.</p></header>${b.categories.map(c=>`<section id="category-${esc(c.id)}"><h2>${esc(c.name)}</h2><div class="grid">${c.services.map(s=>`<article><h3>${esc(s.name)}</h3><p>${esc(s.description)}</p><a class="button" href="https://wa.me/${encodeURIComponent(b.whatsapp)}?text=${encodeURIComponent('SERVICE '+s.id)}" rel="noopener noreferrer">Enquire on WhatsApp</a></article>`).join('')}</div></section>`).join('')}<footer>${esc(b.phone)} · ${esc(b.email)}<p>${esc(b.hours)}</p><p>Requirements, fees and timing are reviewed by our team before work begins.</p></footer></main></body></html>`;
    return respond(200,content,'text/html');
   }
   if(req.method==='GET'&&['/','/admin.js','/style.css'].includes(path)){
    const file=path==='/'?'index.html':path.slice(1);
    return respond(200,readFileSync(new URL('../public/'+file,import.meta.url),'utf8'),file.endsWith('.js')?'text/javascript':file.endsWith('.css')?'text/css':'text/html');
   }
   if(path.startsWith('/api/admin/')){
    const received=Buffer.from(req.headers.authorization||''),expected=Buffer.from(`Bearer ${config.admin}`);
    if(received.length!==expected.length||!timingSafeEqual(received,expected))return respond(401,{error:'Unauthorized'});
    if(req.method==='GET'&&path==='/api/admin/overview')return respond(200,{business:b.name,dryRun:config.dryRun,contacts:db.prepare('SELECT chat,state,updated FROM contacts ORDER BY updated DESC LIMIT 200').all(),leads:db.prepare('SELECT * FROM leads ORDER BY id DESC LIMIT 200').all(),outbox:db.prepare('SELECT * FROM outbox ORDER BY id DESC LIMIT 100').all()});
    if(req.method==='POST'&&path==='/api/admin/action'){
     const action=JSON.parse(await readBody(req));
     if(action.type==='resume'||action.type==='pause'){
      const r=db.prepare('UPDATE contacts SET state=?,updated=? WHERE chat=?').run(JSON.stringify({stage:action.type==='resume'?'menu':'human'}),Date.now(),action.chat);
      if(!r.changes)return respond(404,{error:'Contact not found'});
      db.prepare("UPDATE outbox SET status='cancelled' WHERE chat=? AND status='pending'").run(action.chat);
     }else if(action.type==='lead-status'&&['new','contacted','closed'].includes(action.status)){
      const r=db.prepare('UPDATE leads SET status=? WHERE id=?').run(action.status,action.id);if(!r.changes)return respond(404,{error:'Lead not found'});
     }else if(action.type==='discard'){
      db.prepare("UPDATE outbox SET status='cancelled' WHERE id=? AND status IN ('review','failed')").run(action.id);
     }else if(action.type==='retry'&&action.confirmed===true){
      db.prepare("UPDATE outbox SET status='pending',next=0,error=NULL WHERE id=? AND status IN ('review','failed')").run(action.id);
     }else return respond(400,{error:'Unsupported action'});
     return respond(200,{status:'ok'});
    }
   }
   respond(404,{error:'Not found'});
  }catch(e){respond(e.status||400,{error:e.status===413?'Body too large':'Request could not be processed'});}
 });
 server.requestTimeout=15000;server.headersTimeout=10000;
 return server;
}
