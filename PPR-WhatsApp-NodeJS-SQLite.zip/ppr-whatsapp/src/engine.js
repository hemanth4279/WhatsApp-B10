import {flow} from './flow.js';
import {transaction} from './store.js';
import {api} from './openwa.js';
export function accept(db,event,session) {
 if(event.sessionId!==session || event.event!=='message.received')return 'ignored';
 const d=event.data;
 if(!d || d.fromMe!==false || d.isGroup===true || d.kind==='group')return 'ignored';
 const chat=d.chatId||d.from;
 if(typeof chat!=='string'||!/^\d+@(c\.us|s\.whatsapp\.net|lid)$/.test(chat))return 'ignored';
 if(typeof d.body!=='string'||!d.body.trim()||d.body.length>2000||d.media)return 'ignored';
 const id=typeof d.id==='string'?d.id:d.id?._serialized;
 if(!id)return 'invalid';
 // Use session + stable message id, not a delivery id which changes on webhook retries.
 const key=`${session}:${id}`;
 const result=db.prepare('INSERT OR IGNORE INTO inbox(key,chat,body,received) VALUES(?,?,?,?)').run(key,chat,d.body,Date.now());
 return result.changes?'queued':'duplicate';
}
export function processInbox(db,b,config) {
 const messages=db.prepare("SELECT * FROM inbox WHERE status='pending' ORDER BY received,rowid LIMIT 50").all();
 for(const msg of messages)transaction(db,()=>{
  const stored=db.prepare('SELECT state FROM contacts WHERE chat=?').get(msg.chat);
  const result=flow(b,stored?JSON.parse(stored.state):{},msg.body,{publicBase:config.publicBase});
  db.prepare('INSERT INTO contacts VALUES(?,?,?) ON CONFLICT(chat) DO UPDATE SET state=excluded.state,updated=excluded.updated').run(msg.chat,JSON.stringify(result.state),Date.now());
  if(result.lead)db.prepare('INSERT INTO leads(chat,name,service,enquiry,created) VALUES(?,?,?,?,?)').run(msg.chat,result.lead.name,result.lead.service,result.lead.enquiry,Date.now());
  // STOP/HUMAN cancels queued replies for this contact before adding acknowledgement.
  if(['stopped','human'].includes(result.state.stage))db.prepare("UPDATE outbox SET status='cancelled' WHERE chat=? AND status='pending'").run(msg.chat);
  if(result.text)db.prepare('INSERT OR IGNORE INTO outbox(key,chat,text,created) VALUES(?,?,?,?)').run(msg.key,msg.chat,result.text,Date.now());
  db.prepare("UPDATE inbox SET status='done',body='' WHERE key=?").run(msg.key);
 });
}
export async function sendNext(db,config,send=(body)=>api(config,'messages/send-text',body)) {
 const row=db.prepare("SELECT * FROM outbox o WHERE status='pending' AND next<=? AND NOT EXISTS (SELECT 1 FROM outbox older WHERE older.chat=o.chat AND older.id<o.id AND older.status IN ('pending','sending','review')) ORDER BY id LIMIT 1").get(Date.now());
 if(!row)return;
 db.prepare("UPDATE outbox SET status='sending',attempts=attempts+1 WHERE id=?").run(row.id);
 if(config.dryRun){db.prepare("UPDATE outbox SET status='simulated' WHERE id=?").run(row.id);return;}
 try {await send({chatId:row.chat,text:row.text});db.prepare("UPDATE outbox SET status='sent',error=NULL WHERE id=?").run(row.id);}
 catch(e){
  // A rate-limit rejection is safe to retry; network errors / server errors may follow acceptance.
  const status=e.status===429 && row.attempts<4?'pending':e.status>=400&&e.status<500?'failed':'review';
  db.prepare('UPDATE outbox SET status=?,next=?,error=? WHERE id=?').run(status,Date.now()+1000*(e.retryAfter||5),String(e.message).slice(0,200),row.id);
 }
}
