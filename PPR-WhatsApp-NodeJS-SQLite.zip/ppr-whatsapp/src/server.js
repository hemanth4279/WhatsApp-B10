import {readFileSync} from 'node:fs';
import {configFromEnv} from './config.js';
import {openStore} from './store.js';
import {httpServer} from './http.js';
import {processInbox,sendNext} from './engine.js';
process.umask(0o077);
const config=configFromEnv();
const b=JSON.parse(readFileSync(new URL('../config/business.json',import.meta.url)));
if(config.ceoMode)b.ceoWelcome=`A welcome from ${b.leader}, CEO: “Welcome to ${b.name}. Thank you for trusting us with your tax and business compliance needs. Our team is here to assist you.”`;
const db=openStore(config.db),server=httpServer(db,b,config);
let busy=false,closing=false;
const timer=setInterval(async()=>{if(busy||closing)return;busy=true;try{processInbox(db,b,config);await sendNext(db,config);}catch{console.error('Worker failed; pending work is retained. Inspect configuration and database.');}finally{busy=false;}},750);
function purge(){const cut=Date.now()-config.retention*86400000;
 db.prepare("DELETE FROM inbox WHERE status='done' AND received<?").run(cut);
 db.prepare("DELETE FROM outbox WHERE status IN ('sent','simulated','cancelled') AND created<?").run(cut);
 db.prepare("DELETE FROM leads WHERE status='closed' AND created<?").run(cut);
 // Keep stopped/human contacts so expiry never silently re-enables automation.
 db.prepare("DELETE FROM contacts WHERE json_extract(state,'$.stage') NOT IN ('stopped','human') AND updated<? AND chat NOT IN (SELECT chat FROM inbox WHERE status='pending') AND chat NOT IN (SELECT chat FROM outbox WHERE status IN ('pending','sending','review'))").run(cut);
}
purge();const cleanup=setInterval(purge,86400000);
server.listen(config.port,config.host,()=>console.log(`PPR automation listening on ${config.host}:${config.port}; ${config.dryRun?'DEMO: no WhatsApp messages sent':'LIVE'}`));
async function shutdown(){if(closing)return;closing=true;clearInterval(timer);clearInterval(cleanup);server.close();while(busy)await new Promise(r=>setTimeout(r,100));db.close();process.exit(0);}
process.on('SIGTERM',shutdown);process.on('SIGINT',shutdown);
