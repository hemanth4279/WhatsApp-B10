import {DatabaseSync} from 'node:sqlite';
import {mkdirSync} from 'node:fs';
import {dirname} from 'node:path';
export function openStore(path) {
 if(path!==':memory:')mkdirSync(dirname(path),{recursive:true,mode:0o700});
 const db=new DatabaseSync(path);
 db.exec(`PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000; PRAGMA foreign_keys=ON;
 CREATE TABLE IF NOT EXISTS contacts(chat TEXT PRIMARY KEY,state TEXT NOT NULL,updated INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS inbox(key TEXT PRIMARY KEY,chat TEXT NOT NULL,body TEXT NOT NULL,received INTEGER NOT NULL,status TEXT NOT NULL DEFAULT 'pending');
 CREATE TABLE IF NOT EXISTS outbox(id INTEGER PRIMARY KEY,key TEXT UNIQUE,chat TEXT NOT NULL,text TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'pending',attempts INTEGER NOT NULL DEFAULT 0,next INTEGER NOT NULL DEFAULT 0,error TEXT,created INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS leads(id INTEGER PRIMARY KEY,chat TEXT NOT NULL,name TEXT NOT NULL,service TEXT NOT NULL,enquiry TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'new',created INTEGER NOT NULL);`);
 // A restart after a send might mean the remote accepted it; do not blindly resend.
 db.exec("UPDATE outbox SET status='review',error='Process restarted during send; check WhatsApp before retrying' WHERE status='sending'");
 return db;
}
export function transaction(db,fn){db.exec('BEGIN IMMEDIATE');try{const r=fn();db.exec('COMMIT');return r;}catch(e){db.exec('ROLLBACK');throw e;}}
