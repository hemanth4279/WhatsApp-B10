export function configFromEnv(env=process.env){
 const dryRun=env.DRY_RUN==='true';
 const port=Number(env.PORT||3090), retention=Number(env.RETENTION_DAYS||30);
 if(!Number.isInteger(port)||port<1||port>65535)throw Error('Invalid PORT');
 if(!Number.isInteger(retention)||retention<1||retention>3650)throw Error('Invalid RETENTION_DAYS');
 for(const field of ['ADMIN_TOKEN','WEBHOOK_SECRET'])if(!env[field]||env[field].length<32||env[field].startsWith('replace'))throw Error(`${field} must be a secret of at least 32 characters`);
 for(const field of ['OPENWA_SESSION_ID','OPENWA_API_KEY'])if(!env[field]||(!dryRun&&env[field].startsWith('replace')))throw Error(`Configure ${field}`);
 const openwa=new URL(env.OPENWA_BASE_URL||'http://127.0.0.1:2785');
 if(!['http:','https:'].includes(openwa.protocol)||openwa.username||openwa.password||openwa.search||openwa.hash||openwa.pathname!=='/')throw Error('OPENWA_BASE_URL must be an HTTP(S) origin');
 const publicBase=(env.PUBLIC_BASE_URL||'').replace(/\/$/,'');
 if(publicBase && new URL(publicBase).protocol!=='https:')throw Error('PUBLIC_BASE_URL must use HTTPS');
 return {host:env.HOST||'127.0.0.1',port,db:env.DB_PATH||'./data/ppr.sqlite',openwa:openwa.origin,key:env.OPENWA_API_KEY,session:env.OPENWA_SESSION_ID,secret:env.WEBHOOK_SECRET,admin:env.ADMIN_TOKEN,publicBase,dryRun,retention,ceoMode:env.CEO_MODE==='true'};
}
