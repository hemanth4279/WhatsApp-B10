export async function api(config,path,body) {
 const r=await fetch(`${config.openwa}/api/sessions/${encodeURIComponent(config.session)}/${path}`,{method:body?'POST':'GET',headers:{'X-API-Key':config.key,'Content-Type':'application/json'},body:body?JSON.stringify(body):undefined,signal:AbortSignal.timeout(10000)});
 if(!r.ok){const e=new Error(`OpenWA HTTP ${r.status}`);e.status=r.status;const delay=Number(r.headers.get('retry-after'));e.retryAfter=Number.isFinite(delay)?Math.min(3600,Math.max(5,delay)):5;throw e;}
 return r.json();
}
