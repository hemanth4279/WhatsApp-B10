import {existsSync,readFileSync,writeFileSync} from 'node:fs';import {randomBytes} from 'node:crypto';
if(existsSync('.env'))throw Error('.env already exists; edit it instead of overwriting');
let s=readFileSync('.env.example','utf8').replace('replace-with-at-least-32-random-characters',randomBytes(32).toString('hex')).replace('replace-with-a-different-32-character-random-secret',randomBytes(32).toString('hex'));
writeFileSync('.env',s,{mode:0o600});console.log('.env created with separate random secrets. Set OPENWA_API_KEY and OPENWA_SESSION_ID before starting.');
