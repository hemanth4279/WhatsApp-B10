import {configFromEnv} from '../src/config.js';import {api} from '../src/openwa.js';
const c=configFromEnv();if(c.dryRun)throw Error('Use live configuration to register a webhook');
const url=process.env.WEBHOOK_URL;if(!url)throw Error('Set WEBHOOK_URL reachable from OpenWA');
const existing=await api(c,'webhooks');
const rows=Array.isArray(existing)?existing:existing.data;
if(!Array.isArray(rows))throw Error('Unexpected webhook list; inspect your OpenWA version');
if(rows.some(w=>w.url===url)){console.log('Webhook URL already registered. Verify its secret/events in the OpenWA dashboard; no duplicate created.');process.exit(0);}
await api(c,'webhooks',{url,events:['message.received'],secret:c.secret});console.log('Webhook registered. Now test with your own WhatsApp number.');
