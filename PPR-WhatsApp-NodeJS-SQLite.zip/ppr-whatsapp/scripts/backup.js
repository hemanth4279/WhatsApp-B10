import {DatabaseSync,backup} from 'node:sqlite';import {mkdirSync,chmodSync} from 'node:fs';
process.umask(0o077);mkdirSync('backups',{recursive:true,mode:0o700});
const target=`backups/ppr-${new Date().toISOString().replace(/[:.]/g,'-')}.sqlite`;
const db=new DatabaseSync(process.env.DB_PATH||'./data/ppr.sqlite',{readOnly:true});await backup(db,target);db.close();chmodSync(target,0o600);console.log('Backup saved: '+target);
