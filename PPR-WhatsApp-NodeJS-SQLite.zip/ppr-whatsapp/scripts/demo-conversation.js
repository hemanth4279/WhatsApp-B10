import {createHmac} from 'node:crypto';
if(process.env.DRY_RUN!=='true')throw Error('This fixture is only for dry-run mode');
const base=`http://127.0.0.1:${process.env.PORT||3090}`;
let ready=false;
for(let attempt=0;attempt<20;attempt++){try{ready=(await fetch(base+'/health')).ok;if(ready)break;}catch{}await new Promise(r=>setTimeout(r,100));}
if(!ready)throw Error('Start npm run demo in another terminal before running the fixture');
for(const [index,body] of ['hi','2','1','BOOK','YES','Hemanth','Need GST registration. Afternoon callback preferred.'].entries()){
 const raw=JSON.stringify({event:'message.received',timestamp:new Date().toISOString(),sessionId:process.env.OPENWA_SESSION_ID,data:{id:`demo-${Date.now()}-${index}`,chatId:'910000000000@c.us',body,fromMe:false,isGroup:false}});
 const r=await fetch(base+'/webhook/openwa',{method:'POST',headers:{'Content-Type':'application/json','X-OpenWA-Signature':'sha256='+createHmac('sha256',process.env.WEBHOOK_SECRET).update(raw).digest('hex')},body:raw});
 if(!r.ok)throw Error(`Fixture HTTP ${r.status}`);
 // Exercise the real background worker without calling WhatsApp.
 await new Promise(r=>setTimeout(r,1000));
 console.log(`Input ${index+1}: ${body}`);
}
const r=await fetch(base+'/api/admin/overview',{headers:{Authorization:'Bearer '+process.env.ADMIN_TOKEN}});const data=await r.json();
console.log(`Captured ${data.leads.length} lead(s). Outbox: ${data.outbox.map(x=>x.status).join(', ')}. No live WhatsApp messages sent.`);
