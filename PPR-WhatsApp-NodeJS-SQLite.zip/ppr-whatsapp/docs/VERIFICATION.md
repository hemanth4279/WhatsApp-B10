# Verification — 4 October 2026

Environment: Node.js v24.19.0. No live OpenWA credentials or WhatsApp session supplied.

`npm test`: 12 tests passed; zero failed. Final run duration approximately 141 ms.

Coverage: 36 service entries; category navigation; callback consent and name/enquiry capture; stopped/human state behaviour; ignored groups, outgoing, media and wrong-session events; deduplication and one lead per processed flow; STOP cancellation; uncertain send review/order blocking; capped rate-limit retries; exact-byte signature verification; HTTP health/catalog/admin/signed intake/stale replay/actions; missing-secret rejection.

End-to-end local demo: `node --env-file=.env.demo src/server.js`, then `node --env-file=.env.demo scripts/demo-conversation.js`.

Observed inputs:

```text
Input 1: hi
Input 2: 2
Input 3: 1
Input 4: BOOK
Input 5: YES
Input 6: Hemanth
Input 7: Need GST registration. Afternoon callback preferred.
Captured 1 lead(s). Outbox: simulated, simulated, simulated, simulated, simulated, simulated, simulated. No live WhatsApp messages sent.
```

Online SQLite backup script completed successfully against the local demo database. Demo database and backup files are excluded from the ZIP.

Not verified here: Docker image build/runtime on the user's EC2, running gateway version/schema, private DNS/SSRF allowlist, real HMAC delivery from their gateway, WhatsApp transmission or native mobile rendering, public HTTPS deployment, staff dashboard visual rendering in a browser. Dashboard routes, catalogue markup and API actions were exercised over local HTTP. Follow README's own-number smoke test before client use.

This ZIP is a runnable integration package, not an already deployed or externally audited system. It has no production credentials.
