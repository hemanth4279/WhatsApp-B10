# Sources and integration evidence

Retrieved 4 October 2026.

Business source: https://ppr-tax-consultancy-eilu.bolt.host
Public bundle containing business configuration: https://ppr-tax-consultancy-eilu.bolt.host/assets/index-BU70V2DH.js
HTML title/meta and bundle business configuration were fetched successfully. The source website may change; the packaged business.json is a dated extraction, not a live sync. Marketing claims, testimonials and client-count claims were not added to the chatbot.

Gateway primary project: https://github.com/rmyndharis/OpenWA
Send-text and registration: https://github.com/rmyndharis/OpenWA/blob/main/docs/07-api-collection.md
Incoming event format: https://github.com/rmyndharis/OpenWA/blob/main/docs/12-troubleshooting-faq.md
Signing: https://github.com/rmyndharis/OpenWA/blob/main/docs/04-security-design.md
Private sidecar allowlist: https://github.com/rmyndharis/OpenWA/blob/main/.env.example
Native button/list limitation: https://github.com/jonathan-o-lima/openwa/blob/main/docs/07-api-collection.md (project fork; confirm against your installed gateway).

Several similarly named OpenWA projects exist. This package targets the NestJS gateway with sessions, send-text and webhooks endpoints, as used by your existing setup. It is not an @open-wa/wa-automate embedded client. Schema compatibility with the user's running server was not verified because credentials/server access were not provided.
